=======
History
=======

0.1.0 (2018-03-15)
------------------

* First release on PyPI.

0.1.1 (2018-03-15)
------------------

* Second release on PyPI.
